// load the page in jsdom with a fake canvas, then expose a driver
const {JSDOM}=require('jsdom');const fs=require('fs');
function stub(){const f=function(){return stub()};return new Proxy(f,{get(t,p){
  if(p==='getImageData'||p==='createImageData')return (a,b,w,h)=>({data:new Uint8ClampedArray((w||a)*(h||b)*4)});
  if(p===Symbol.toPrimitive)return()=>0;if(p==='then')return undefined;
  if(p in t)return t[p];return stub()},set(t,p,v){t[p]=v;return true}})}
module.exports=function load(opts={}){
  const html=fs.readFileSync(opts.file||require('path').join(__dirname,'..','mind-vessel.html'),'utf8').replace(/<link[^>]*>/g,'');
  const errors=[];
  const dom=new JSDOM(html,{runScripts:'outside-only',pretendToBeVisual:true,url:'https://example.test/'});
  const w=dom.window;
  w.HTMLCanvasElement.prototype.getContext=()=>stub();
  const W=opts.w||1280,H=opts.h||800;
  w.innerWidth=W;w.innerHeight=H;
  w.Element.prototype.getBoundingClientRect=function(){if(this.id==='cv'||this.id==='vw')return{left:6,top:30,width:W-12,height:opts.narrow?H*.55:H*.6,right:W-6,bottom:H};if(this.id==='reg')return{left:0,top:0,width:640,height:312};return{left:0,top:0,width:100,height:20,right:100,bottom:20}};
  w.matchMedia=q=>({matches:/max-width:860px/.test(q)?!!opts.narrow:false,addEventListener(){},addListener(){}});
  w.requestAnimationFrame=()=>0;
  w.localStorage.setItem('mindvessel.coached2','1');w.localStorage.setItem('mindvessel.uimode',opts.simple?'simple':'detailed');
  w.addEventListener('error',e=>errors.push(e.message));
  const src=html.match(/<script>([\s\S]*)<\/script>/)[1]
    .replace("newVessel();updFk();uiTick();","newVessel();updFk();uiTick();window.__g={get player(){return player},get RG(){return RG},get insp(){return insp},get placing(){return placing},get toasts(){return toasts},get drawerOpen(){return drawerOpen},get dockTab(){return dockTab},get sheet(){return sheet},get mapOpen(){return mapOpen},get regSel(){return regSel},get save(){return save},get exits(){return exits},get actors(){return actors},get objs(){return objs},get barks(){return barks},get paused(){return paused},set paused(v){paused=v},get chronicle(){return chronicle},get cam(){return cam},get stats(){return stats},get gameTime(){return gameTime},TS,MW,MH,VW,VH,update,uiTick,updBarks,toast,openCard,closeCard,cmd,addThought,bestSlot,previewText,previewAt,newVessel,leaveSite,enterSite,setSheet,showDock,toggleDrawer,openMap,closeMap,think,mindCost,idx,explored:()=>explored,vis:()=>vis,map:()=>map,rlog,TH,closeDlg,suggestFor,regionLive,get layout(){return layout},get SIMPLE(){return SIMPLE},setSimple,askWay,recallDead,surveyLines,get objsNow(){return objs},killNow2:(a,s)=>kill(a,s),get vmem(){return vmem},travel,abandon,lightAt:i=>LIGHT[i],rebuildEnvNow:()=>rebuildEnv(),killNow:(a,s)=>kill(a,s),kindMix,npcLeaveNow:(a,to)=>npcLeave(a,to),spawnAt,pickKind,showDeath,get heardN(){return heardN},newsAdd,hearNews,scanFeed,gossipStep,get logPinned(){return logPinned},ductDbg:()=>{const a=player;return{on:$('ducts').classList.contains('on'),flash:realT()<ductFlashT,hold:realT()<ductHold,travel:!!(a.intent&&a.intent.v==='TRAVEL'),att:patience(a)-(a.focus.all||0)<30,sel:!!(selTh&&a.mind.includes(selTh)&&TH[selTh].v.some(v=>v[0]==='TRAVEL')),pulse:exits.some(e=>explored[e.i]&&(RG.sites[e.to].pulseT||0)-gameTime>22)}},applyLayout,frameStep:(dt)=>{if(!paused&&!dlgOpen&&!player.dead)update(dt);updFx(dt);updBarks(dt);uiTick()}};")
    .replace(/requestAnimationFrame\(frame\);\s*$/,'');
  try{w.eval(src)}catch(e){errors.push('LOAD: '+e.stack.split('\n').slice(0,3).join(' | '))}
  return{w,d:w.document,g:w.__g,errors,$:id=>w.document.getElementById(id)};
};
