const load=require('./dom.js');const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
const {g,d,$,w,errors}=load({w:1920,h:1080,simple:true});g.closeDlg();g.uiTick();
// over capacity
const P=g.player;P.mindCap=g.mindCost(P);const big=Object.keys(g.TH).find(t=>!g.TH[t].hidden&&!P.mind.includes(t)&&g.TH[t].c>=1);if(!g.save.lib.includes(big))g.save.lib.push(big);
g.addThought(big,0);ok($('capline').classList.contains('full')&&g.barks.some(b=>/no room/.test(b.el.textContent)),'over capacity: pips flash and the vessel says "'+(g.barks.find(b=>/no room/.test(b.el.textContent))||{el:{}}).el.textContent+'"');P.mindCap+=4;
// Thought card by tap
d.querySelector('#mindrows [data-lib]').click();g.uiTick();const card=d.querySelector('#lib .card');card.click();g.uiTick();ok(!$('card').hidden&&g.insp.kind==='thought'&&/costs/.test($('card').textContent),'tapping a Library card opens its card: '+$('card').textContent.replace(/\s+/g,' ').slice(0,90));
ok(!!$('card').querySelector('[data-sug]'),'the card can add it');
const row=d.querySelector('#mindrows .th');row.click();g.uiTick();const row2=d.querySelector('#mindrows .th');row2.click();g.uiTick();ok(g.insp&&g.insp.kind==='thought'&&g.insp.tid===row2.dataset.t,'tapping a selected Mind row again opens its card (with live verb reasons)');
// pause reason
g.w=0;const ap=w.eval?null:null;
g.cmd('p');g.cmd('p');
// confirmations
$('b-menu').click();const ab=$('menu').querySelector('[data-k="n"]');const name=P.comp.name;ab.click();ok(!$('menu').hidden&&/Click again/.test($('menu').textContent),'first Abandon click keeps the menu open and asks to click again');
$('menu').querySelector('[data-k="n"]').click();ok(g.player.comp.name!==name,'second click abandons');
g.closeDlg();
// help legend
g.cmd('h');ok(/Simple mode/.test($('dlg-b').textContent)&&$('dlg-b').querySelectorAll('.ico').length>20,'help shows the glyph legend ('+$('dlg-b').querySelectorAll('.ico').length+' glyphs)');g.closeDlg();
ok(errors.length===0,'no errors '+errors.slice(0,2));
