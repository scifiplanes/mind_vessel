const load=require('./dom.js');const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
const {g,d,$,w,errors}=load({w:1920,h:1080});g.closeDlg();let fake=w.performance.now();w.performance.now=()=>fake;const step=n=>{for(let i=0;i<n;i++){fake+=1000/60;g.frameStep(1/60)}};
step(60*20);
const A=g.player,start=g.RG.cur;A.mind=[];A.inv.metal=4;A.inv.cable=3;const gear=A.equip.hand||null;const aName=A.comp.name;const ax=A.x|0,ay=A.y|0;
const exA=g.explored().reduce((a,b)=>a+b,0);
// A explores a neighbour, then comes back and dies at the start site
const nb=g.RG.sites[start].nb[0];g.leaveSite();g.enterSite(nb,start,[]);A.mind=['restless'];step(60*25);A.mind=[];const exNb=g.explored().reduce((a,b)=>a+b,0);g.leaveSite();g.enterSite(start,nb,[]);
ok(g.explored().reduce((a,b)=>a+b,0)>=exA,'the same vessel keeps its own fog of war when it returns');
A.x=ax+.5;A.y=ay+.5;A.mind=['survive','forager'];g.killNow2(A,'test');
const os=g.objsNow;const remains=os.find(o=>o.vessel===aName);ok(!!remains,`body left: "${remains&&remains.name}"`);
const items=os.filter(o=>o.k==='item'&&Math.abs(o.x-ax)<=3&&Math.abs(o.y-ay)<=3);const mats=items.filter(o=>o.it.t==='mat').map(o=>o.it.mat+'×'+o.it.n);
ok(mats.some(m=>m.startsWith('metal×4'))&&mats.some(m=>m.startsWith('cable×3')),'pack dropped: '+mats.join(', '));
ok(!gear||items.some(o=>o.it===gear),'gear dropped'+(gear?': '+gear.name:' (had none)'));
ok(items.some(o=>o.it.t==='shard'&&o.it.th),'one of its Thoughts left as a shard: '+(items.find(o=>o.it.t==='shard')||{it:{}}).it.th);
// next vessel
step(60*3);g.newVessel();g.closeDlg();const B=g.player;
ok(B!==A&&g.RG.cur===g.RG.start,'a new vessel wakes at the campaign start');
const exB=g.explored().reduce((a,b)=>a+b,0);ok(exB<exA,`the new vessel does not inherit the old fog of war (${exA} → ${exB} tiles known)`);
ok(!g.RG.sites[nb].visited,'map knowledge is the new vessel\'s own: the neighbour is not marked visited');
ok(g.objsNow.some(o=>o.vessel===aName)&&g.objsNow.some(o=>o.k==='item'&&o.it.t==='mat'&&o.it.mat==='metal'&&o.it.n===4),'the world kept the old vessel\'s remains and its metal');
g.openCard({kind:'obj',o:g.objsNow.find(o=>o.vessel===aName),pinned:true});ok(/past vessel/.test($('card').textContent),'card: '+$('card').textContent.replace(/\s+/g,' ').slice(0,80));
// mined tiles persist across vessels
const W=g.map();let wall=-1;for(let i=0;i<W.length;i++)if(!W[i]){wall=i;break}
// travelling away and back with the new vessel keeps the world, with B's own fog
g.leaveSite();g.enterSite(nb,start,[]);ok(g.explored().reduce((a,b)=>a+b,0)<exNb||exNb===0,'the old vessel\'s exploration of the neighbour is not inherited');g.leaveSite();g.enterSite(start,nb,[]);
ok(g.objsNow.some(o=>o.vessel===aName),'remains still there after travelling');
// abandon also leaves remains
const bn=g.player.comp.name;g.abandon();g.closeDlg();ok(g.objsNow.some(o=>o.vessel===bn)||g.RG.sites[g.RG.cur].fallen.includes(bn),'abandoning leaves the vessel behind too');
step(60*10);ok(errors.length===0,'no errors '+errors.slice(0,2));
