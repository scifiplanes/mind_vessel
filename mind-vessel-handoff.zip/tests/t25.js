const load=require('./dom.js');const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
const {g,d,$,w,errors}=load({w:1920,h:1080,simple:true});g.closeDlg();let fake=w.performance.now();w.performance.now=()=>fake;
const seen=[];for(let i=0;i<60*3;i++){fake+=1000/60;g.frameStep(1/60);for(const b of g.barks)if(!seen.includes(b.el.textContent))seen.push(b.el.textContent)}
g.uiTick();ok(!/·/.test($('hdr-site').textContent),'Simple header is just the site name: "'+$('hdr-site').textContent+'"');
ok(seen.some(t=>/^…/.test(t)),'on arrival the vessel senses the site: '+seen.filter(t=>/^…/.test(t)).join(', '));
for(const ph of ['collapse','primordial','complex']){const s=g.RG.sites.find(s=>s.phase===ph&&s.id!==g.RG.cur);if(!s)continue;g.leaveSite();g.enterSite(s.id,null,[]);const got=[];for(let i=0;i<60*3;i++){fake+=1000/60;g.frameStep(1/60);for(const b of g.barks)if(/^…/.test(b.el.textContent)&&!got.includes(b.el.textContent))got.push(b.el.textContent)}console.log('     ',ph,'→',got.join(' '))}
g.cmd('u');g.uiTick();ok(/·/.test($('hdr-site').textContent),'Detailed header keeps tier, state and time');
ok(errors.length===0,'no errors '+errors.slice(0,2));
