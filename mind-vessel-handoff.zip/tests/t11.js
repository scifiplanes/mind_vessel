const load=require('./dom.js');const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
for(const o of [{w:1920,h:1080},{narrow:true,w:390,h:844}]){const {g,d,$,errors}=load(o);g.closeDlg();g.showDock('ves');g.uiTick();
 for(const sel of ['[data-st="WIS"]','[data-st="END"]','[data-tr]','[data-ab="sp"]','[data-ab="cls"]']){const el=d.querySelector('#sh-stat '+sel);if(!el){ok(false,'missing '+sel);continue}
   el.click();g.uiTick();ok(!$('card').hidden,`${o.narrow?'phone':'desktop'}: ${el.textContent.trim()} → ${$('card').textContent.replace(/\s+/g,' ').slice(0,110)}`)}
 ok(errors.length===0,'no errors '+errors.slice(0,2))}
