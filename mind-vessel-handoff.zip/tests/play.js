const fs=require('fs');
function stub(){const f=function(){return stub()};return new Proxy(f,{get(t,p){
  if(p==='getImageData'||p==='createImageData')return (a,b,w,h)=>({data:new Uint8ClampedArray((w||a)*(h||b)*4)});
  if(p==='getBoundingClientRect')return()=>({left:0,top:0,width:640,height:384});
  if(p===Symbol.toPrimitive)return()=>0;
  if(p in t)return t[p]; return stub();},set(t,p,v){t[p]=v;return true}})}
const els={};
global.document={getElementById:id=>els[id]||(els[id]=Object.assign(stub(),{children:{length:0}})),createElement:()=>{const c=stub();c.getContext=()=>stub();return c},documentElement:stub(),addEventListener(){},querySelectorAll:()=>[]};
global.innerWidth=1280;global.addEventListener=()=>{};global.HTMLElement=function(){};global.innerHeight=800;global.localStorage={getItem:()=>null,setItem(){}};global.performance={now:()=>Date.now()};global.requestAnimationFrame=()=>{};global.setTimeout=()=>{};
let logs=[];let src=fs.readFileSync(process.argv[4]||'game.js','utf8').replace("function log(msg,cls){","function log(msg,cls){logs.push(msg);");
src+=`;closeDlg();
const N=+process.argv[2],MIN=+process.argv[3];const rows=[];
for(let v=0;v<N;v++){
  if(v>0)newVessel();logs=[];
  const who=player.comp.species+' '+player.comp.cls+' ['+player.mind.map(t=>TH[t].n).join(', ')+']';
  let t=0,idle=0,lowE=0,travels=0,sameSite=0,lastSite=RG.cur,lastMove=0,stuckMax=0,lx=player.x,ly=player.y,verbs={};
  for(;t<60*60*MIN&&!player.dead;t++){update(1/60);updFx(1/60);
    if(!player.intent&&!player.busy)idle++;if(player.energy<15)lowE++;
    if(player.intent)verbs[player.intent.v]=(verbs[player.intent.v]||0)+1;
    if(t%60===0){if(Math.hypot(player.x-lx,player.y-ly)<.3&&!player.busy){lastMove++;stuckMax=Math.max(stuckMax,lastMove)}else lastMove=0;lx=player.x;ly=player.y}
    if(RG.cur!==lastSite){travels++;lastSite=RG.cur}}
  const top=Object.entries(verbs).sort((a,b)=>b[1]-a[1]).slice(0,4).map(e=>e[0]+':'+Math.round(e[1]/60)+'s').join(' ');
  rows.push({who,secs:Math.round(t/60),dead:player.dead?deathCause:'-',tier:depth-1,travels,idle:Math.round(idle/60),lowE:Math.round(lowE/60),stuckMax,top,expl:explored.reduce((a,b)=>a+b,0)});
}
for(const r of rows)console.log(JSON.stringify(r));
`;
eval(src);
