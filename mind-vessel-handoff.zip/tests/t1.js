const load=require('./dom.js');
const T=load();const {g,d,$,w,errors}=T;
const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
if(!g){console.log(errors);process.exit()}
g.closeDlg();
// 1 world runs while the Mind is edited
for(let i=0;i<60*20;i++)g.frameStep(1/60);
ok(errors.length===0,'20s of play with UI ticking, no errors '+errors.slice(0,2));
const rows=d.querySelectorAll('#mindrows .th');ok(rows.length===g.player.mind.length,`Mind dock shows ${rows.length} rows for ${g.player.mind.length} Thoughts`);
const t0=g.gameTime;
// reorder with ▲ while running
if(g.player.mind.length>1){const second=g.player.mind[1];d.querySelector('[data-up="1"]').click();ok(g.player.mind[0]===second,'▲ moves a Thought up while the world runs')}
for(let i=0;i<60;i++)g.frameStep(1/60);ok(g.gameTime>t0,'time kept running during editing');
// remove
const n=g.player.mind.length;d.querySelector('[data-rm="0"]').click();ok(g.player.mind.length===n-1,'× removes a Thought');
// library drawer
g.cmd('l');ok(g.drawerOpen&&$('drawer').classList.contains('open'),'L opens the Library drawer on desktop');
g.uiTick();const cards=d.querySelectorAll('#lib .card');ok(cards.length>0,`drawer lists ${cards.length} cards`);
const stars=d.querySelectorAll('#lib .star').length;console.log('     ★ marks:',stars);
// + add places at best slot
const addB=[...d.querySelectorAll('#lib [data-add]')].find(b=>g.TH[b.dataset.add].c<=g.player.mindCap-g.mindCost(g.player));
if(addB){const tid=addB.dataset.add;addB.click();ok(g.player.mind.includes(tid),'+ adds '+g.TH[tid].n+': '+$('libinfo').textContent.slice(0,90))}
// over-capacity add refused
const big=Object.keys(g.TH).find(t=>g.save.lib.includes(t)&&!g.player.mind.includes(t)&&g.TH[t].c>g.player.mindCap-g.mindCost(g.player));
if(big){ok(!g.addThought(big,0),'over-capacity add refused: '+$('libinfo').textContent.slice(0,70))}
// card on a tile, actor
const pl=g.player;g.openCard({kind:'actor',a:pl,pinned:true});ok(!$('card').hidden&&/you/.test($('card').textContent),'card opens on the vessel');
const wall=(()=>{const m=g.map();for(let i=0;i<m.length;i++)if(!m[i]&&g.explored()[i])return i})();
g.openCard({kind:'tile',i:wall,pinned:true});g.uiTick();ok(!$('card').hidden,'card opens on a wall tile: '+$('card').textContent.slice(0,100).replace(/\s+/g,' '));
const more=$('card').querySelector('[data-more]');if(more){more.click();ok(/leaves/.test($('card').textContent),'more ▾ expands')}
const mlink=$('card').querySelector('[data-m]');if(mlink){mlink.click();ok(g.insp.kind==='mat'&&!!g.insp.back,'material link drills down with back');$('card').querySelector('[data-back]').click();ok(g.insp.kind==='tile','‹ returns to the tile')}
const sug=$('card').querySelector('[data-sug]');console.log('     suggestion on wall:',sug?g.TH[sug.dataset.sug].n:'none');
if(sug){const tid=sug.dataset.sug;sug.click();ok(g.player.mind.includes(tid)&&/added at/.test($('card').textContent),'+ add from card: '+$('card').textContent.match(/added at[^.]*\./))}
d.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));ok($('card').hidden,'Esc closes the card');
// toasts
g.toast('here','Test here',g.RG.cur);g.toast('near','Test near',g.RG.sites[g.RG.cur].nb[0]);for(let i=0;i<5;i++)g.toast('region','Region event '+i,i);
g.uiTick();const ts=d.querySelectorAll('.toast');ok(ts.length<=3,`toasts capped at 3 (${ts.length}); batching: ${(d.querySelector('.toast .more')||{}).textContent}`);
ts[0].click();ok(g.mapOpen&&!$('mapov').hidden,'clicking a toast opens the map at its site '+(g.regSel&&g.regSel.name));
ok(!$('regcard').hidden,'site card shown: '+$('regcard').textContent.slice(0,80));
d.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));ok(!g.mapOpen,'Esc closes the map');
// toast expiry
const now=w.performance.now.bind(w.performance);let fake=now();w.performance.now=()=>fake;fake+=20000;g.uiTick();ok(d.querySelectorAll('.toast').length===0,'toasts expire');w.performance.now=now;
// compass
g.uiTick();ok(!$('compass'),'compass removed');
g.rlog('The Test Order is founded at X.',g.RG.sites[g.RG.cur].nb[0]);ok([...d.querySelectorAll('#log .ln.region')].some(l=>/Test Order/.test(l.textContent))&&![...d.querySelectorAll('.toast')].some(t=>/Test Order/.test(t.textContent)),'region event goes to the Region log, not a toast');
// sheet heights
g.setSheet('peek');ok($('dock').classList.contains('peek')&&/▶/.test($('strip').textContent),'peek shows strip: '+$('strip').textContent.slice(0,60));g.setSheet('half');
g.showDock('ves');g.uiTick();ok(/level/.test($('sh-dyn').textContent)&&/Gear/.test($('sh-stat').textContent),'Vessel tab renders');g.showDock('log');ok(!$('pane-log').hidden,'Log tab');g.showDock('mind');
// menu
$('b-menu').click();ok(!$('menu').hidden&&!/Region toasts/.test($('menu').textContent),'menu opens, no toast settings');d.body.click();ok($('menu').hidden,'click outside closes menu');
// new vessel resets
g.openCard({kind:'actor',a:g.player,pinned:true});g.newVessel();g.closeDlg();g.uiTick();ok($('card').hidden&&!g.placing,'new vessel closes card and placing');
for(let i=0;i<60*30;i++)g.frameStep(1/60);
ok(errors.length===0,'30 more seconds, errors: '+errors.slice(0,3).join(' | '));
