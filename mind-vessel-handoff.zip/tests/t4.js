const load=require('./dom.js');
const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
// ---------- phone
{const T=load({narrow:true,w:390,h:844});const {g,d,$,errors}=T;g.closeDlg();
 for(let i=0;i<60*10;i++)g.frameStep(1/60);
 ok($('pane-lib').contains($('lib-pane')),'phone: Library lives in the dock');
 g.cmd('l');ok(g.dockTab==='lib'&&!$('pane-lib').hidden,'phone: L opens the Library tab in the sheet');
 g.uiTick();const add=[...d.querySelectorAll('#lib [data-add]')].find(b=>g.TH[b.dataset.add].c<=g.player.mindCap-g.mindCost(g.player));
 if(add){const tid=add.dataset.add;add.click();ok(g.placing===tid&&g.dockTab==='mind','phone: + starts placing and returns to the Mind');
   g.uiTick();const slots=d.querySelectorAll('#mindrows .slot[data-slot]');ok(slots.length===g.player.mind.length+1,`phone: ${slots.length} placement slots with previews: "${slots[0].textContent.slice(0,60)}"`);
   slots[1].click();ok(g.player.mind[1]===tid&&!g.placing,'phone: tapping a slot inserts there')}
 else ok(false,'no affordable card to place');
 // cancel placing
 const add2=[...d.querySelectorAll('#lib [data-add]')][0];if(add2){g.showDock('lib');g.uiTick();const b=[...d.querySelectorAll('#lib [data-add]')][0];if(b){b.click();g.uiTick();d.querySelector('[data-cancel]').click();ok(!g.placing,'phone: cancel placing')}}
 g.setSheet('peek');ok(d.getElementById('app').classList.contains('sheet-peek'),'phone: peek');g.setSheet('full');ok(d.getElementById('app').classList.contains('sheet-full'),'phone: full');
 $('handle').click();ok(g.sheet==='peek','phone: handle cycles full → peek');$('handle').click();ok(g.sheet==='half','phone: → half');
 ok(d.querySelectorAll('#mindrows .thb button').length===g.player.mind.length*2,'phone: ▲▼ on every row');
 g.openCard({kind:'actor',a:g.player,pinned:true});g.uiTick();ok(!$('card').hidden,'phone: card shows (CSS docks it to the bottom)');
 for(let i=0;i<60*20;i++)g.frameStep(1/60);ok(errors.length===0,'phone: 30s no errors '+errors.slice(0,2))}
// ---------- edge cases
{const T=load();const {g,d,$,errors,w}=T;g.closeDlg();
 for(let i=0;i<60*5;i++)g.frameStep(1/60);
 // preview must not change the vessel
 const P=g.player,snap=()=>JSON.stringify({mind:P.mind,x:P.x,y:P.y,inv:P.inv,exT:P.exT,wT:P.wT,travelTo:P.travelTo,hp:P.hp,en:P.energy,focus:P.focus,bad:[...(P.bad||new Map()).keys()]});
 const before=snap();for(const t of g.save.lib)for(let at=0;at<=P.mind.length;at++)g.previewAt(t,at);ok(snap()===before,'preview leaves the vessel untouched');
 // preview cost
 const t0=Date.now();for(let k=0;k<20;k++)for(const t of g.save.lib)g.previewAt(t,0);const per=(Date.now()-t0)/(20*g.save.lib.length);ok(per<3,`preview costs ${per.toFixed(2)} ms each (${g.save.lib.length} Thoughts → ${(per*g.save.lib.length).toFixed(0)} ms per ★ refresh)`);
 // travel with card and map open
 g.openCard({kind:'actor',a:g.player,pinned:true});g.openMap(g.RG.cur);
 const to=g.RG.sites[g.RG.cur].nb[0];g.leaveSite();g.enterSite(to,null,[]);g.uiTick();ok($('card').hidden,'travel closes the card');ok(errors.length===0,'map open across travel ok');g.closeMap();
 // card on an object that disappears
 const o=g.objs.find(o=>o.k==='item')||g.objs[0];if(o){g.openCard({kind:'obj',o,pinned:true});g.objs.splice(g.objs.indexOf(o),1);g.uiTick();ok($('card').hidden,'card closes when its object is gone')}
 // card on an actor that dies
 const a=g.actors.find(a=>a!==g.player&&!a.dead);if(a){g.openCard({kind:'actor',a,pinned:true});a.dead=true;g.uiTick();ok($('card').hidden,'card closes when its creature dies')}
 // death with drawer, card, placing
 g.toggleDrawer(true);g.openCard({kind:'actor',a:g.player,pinned:true});g.player.hp=0;
 for(let i=0;i<60*4;i++){g.frameStep(1/60)}ok(errors.length===0,'death with drawer and card open: '+errors.slice(0,2));
 g.newVessel();g.closeDlg();for(let i=0;i<60*5;i++)g.frameStep(1/60);ok(errors.length===0&&!g.player.dead,'new vessel after death');
 // empty Mind
 g.player.mind.length=0;g.uiTick();ok(/Empty/.test($('mindrows').textContent),'empty Mind message');for(let i=0;i<60*5;i++)g.frameStep(1/60);ok(errors.length===0,'runs with empty Mind');
 // drag preview text
 const ev=(type,el,data)=>{const e=new w.Event(type,{bubbles:true,cancelable:true});e.dataTransfer={_d:data||'',setData(k,v){this._d=v},getData(){return this._d},effectAllowed:''};el.dispatchEvent(e);return e};
 g.toggleDrawer(true);g.uiTick();const card=d.querySelector('#lib .card');if(card){ev('dragstart',card);ev('dragover',$('mindrows'));ok(/would|wait/.test($('now').textContent),'drag shows live preview: '+$('now').textContent.slice(0,80));ev('drop',$('mindrows'),'add:'+card.dataset.t);ok(g.player.mind.includes(card.dataset.t),'drop adds')}
 // keyboard: shortcuts don't fire while typing in search
 const q=d.getElementById('libq');if(q){q.focus();const sp=g.paused;q.dispatchEvent(new w.KeyboardEvent('keydown',{key:'m',bubbles:true}));ok(!g.mapOpen,'typing in search does not trigger shortcuts')}
 // space on focused button doesn't pause twice
 // toasts while paused don't expire on game time
 g.paused=true;g.toast('here','paused toast',g.RG.cur);g.uiTick();ok([...d.querySelectorAll('.toast')].some(t=>/paused toast/.test(t.textContent)),'toasts appear while paused');g.paused=false;
 // wipe region with map and card open
 g.openMap(g.RG.cur);g.openCard({kind:'actor',a:g.player,pinned:true});g.cmd('w');g.cmd('w');g.closeDlg();for(let i=0;i<60*3;i++)g.frameStep(1/60);ok(errors.length===0&&!g.mapOpen&&$('card').hidden,'wipe region with overlays open');
 console.log('errors:',errors.slice(0,4))}
