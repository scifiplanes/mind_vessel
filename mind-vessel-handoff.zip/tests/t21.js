const load=require('./dom.js');const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
for(const o of [{w:1920,h:1080,simple:true},{w:1100,h:860,simple:true},{narrow:true,w:390,h:844,simple:true}]){
 const {g,d,$,w,errors}=load(o);g.closeDlg();let fake=w.performance.now();w.performance.now=()=>fake;const step=n=>{for(let i=0;i<n;i++){fake+=1000/60;g.frameStep(1/60)}};
 const tag=o.narrow?'phone':o.w>1500?'wide':'narrow desktop';step(60*10);
 ok(g.SIMPLE&&$('app').classList.contains('simple'),`${tag}: Simple mode is the default`);
 const rows=[...d.querySelectorAll('#mindrows .th')];ok(rows.length===g.player.mind.length&&rows.every(r=>r.querySelector('.ico')&&r.querySelector('.band')&&r.querySelector('.nm')),`${tag}: Mind rows: band, glyph, name (${rows.map(r=>r.querySelector('.nm').textContent).join(', ')})`);
 const whyText=rows.map(r=>r.querySelector('.why').textContent.trim()).filter(t=>t&&!t.startsWith('→'));ok(whyText.length===0,`${tag}: no reason text in rows (only icons and destinations)`);
 ok(!!d.querySelector('.attn')||!rows.some(r=>r.className.includes('st-run')),`${tag}: attention bar under the running Thought`);
 rows[0].click();g.uiTick();ok(!!d.querySelector('.vrow .v .ico'),`${tag}: selecting a Thought shows its verbs as icons`);
 g.cmd('l');g.uiTick();const cards=[...d.querySelectorAll('#lib .card')];ok(cards.length>0&&cards.every(c=>!c.querySelector('.cv')),`${tag}: Library cards are icon + name + cost (${cards.length})`);
 const stars=cards.filter(c=>c.classList.contains('acts'));ok(!stars.length||cards.indexOf(stars[stars.length-1])<stars.length,`${tag}: cards that act here (${stars.length}) are sorted first`);
 g.openCard({kind:'actor',a:g.player,pinned:true});g.uiTick();const ct=$('card').textContent;ok(!/feeds on|now |Mind /.test(ct)&&!!$('card').querySelector('.mb'),`${tag}: vessel card is bars and icons: "${ct.replace(/\s+/g,' ').slice(0,60)}"`);
 const vb=$('card').querySelector('[data-ves]');if(vb){vb.click();ok(g.dockTab==='ves'&&!$('dock-back').hidden&&$('dock-back').classList.contains('on'),`${tag}: ▤ opens the Vessel sheet with a way back`);$('dock-back').click();ok(g.dockTab==='mind',`${tag}: ‹ back to the Mind`)}
 const W=g.map();let wi=-1;for(let i=0;i<W.length;i++)if(!W[i]&&g.explored()[i]){wi=i;break}
 g.openCard({kind:'tile',i:wi,pinned:true});g.uiTick();const mb=$('card').querySelector('[data-more]');ok(!!mb,`${tag}: wall card is compact with ▾ more: "${$('card').textContent.replace(/\s+/g,' ').slice(0,60)}"`);if(mb){mb.click();ok(/leaves/.test($('card').textContent),`${tag}: more shows the full detail`)}
 g.cmd('u');ok(!g.SIMPLE&&!$('app').classList.contains('simple')&&w.localStorage.getItem('mindvessel.uimode')==='detailed',`${tag}: U switches to Detailed and remembers it`);g.uiTick();ok(!!d.querySelector('#mindrows .th .no'),`${tag}: Detailed rows are back`);g.cmd('u');
 step(60*20);ok(errors.length===0,`${tag}: no errors `+errors.slice(0,2))}
