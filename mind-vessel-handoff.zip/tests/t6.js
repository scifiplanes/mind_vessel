const load=require('./dom.js');const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
const {g,d,$,w,errors}=load({w:1920,h:1080});g.closeDlg();
const P=()=>g.player;
// find a moment with no travel in play
let quiet=0,shown=0,steps=0;
for(let i=0;i<60*120;i++){g.frameStep(1/60);if(i%15===0){steps++;$('ducts').classList.contains('on')?shown++:quiet++}}
ok(quiet>0,`markers hidden most of the time: shown ${Math.round(shown/steps*100)}% of 2 min`);
const known=g.exits.filter(e=>g.explored()[e.i]);console.log('     known ducts:',known.length,'| markers:',d.querySelectorAll('.duct').length);
// travel row shows its route
const travelT=Object.keys(g.TH).find(t=>g.TH[t].v.some(v=>v[0]==='TRAVEL')&&g.save.lib.includes(t));
if(travelT){if(!P().mind.includes(travelT))P().mind.push(travelT);g.uiTick();const row=d.querySelector(`#mindrows [data-t="${travelT}"]`);ok(row&&/→/.test(row.textContent),'travel row shows route: '+(row?row.textContent.replace(/\s+/g,' ').slice(0,60):''));
  row.click();for(let i=0;i<3;i++)g.frameStep(1/60);ok($('ducts').classList.contains('on')===(known.length>0)||known.length===0,'selecting a travel Thought shows markers');
  if(known.length){const m=d.querySelector('.duct');ok(!!m,'marker text: '+m.textContent+' | route amber: '+m.classList.contains('rt'));m.click();ok(g.insp&&g.insp.kind==='tile'&&/Duct/.test($('card').textContent),'clicking a marker opens the duct card');}
  row.click()}
// a new duct flashes markers; force by marking an exit explored
const unk=g.exits.find(e=>!g.explored()[e.i]);if(unk){g.explored()[unk.i]=1;for(let i=0;i<3;i++)g.frameStep(1/60);ok($('ducts').classList.contains('on'),'discovering a duct shows markers briefly')}
// off-screen marker sits inside the viewport bounds
for(const el of d.querySelectorAll('.duct')){const x=parseFloat(el.style.left),y=parseFloat(el.style.top);ok(x>=6&&x<=1914&&y>=30&&y<=30+1080*.6,`marker "${el.textContent}" at ${x|0},${y|0} within the world view`)}
// travel to next site clears markers
const to=g.exits[0].to;g.leaveSite();g.enterSite(to,null,[]);for(let i=0;i<3;i++)g.frameStep(1/60);ok([...d.querySelectorAll('.duct')].every(el=>g.exits.some(e=>e.i===+el.dataset.i)),'markers belong to the new site after travel');
$('hdr-site').click();ok(g.mapOpen,'header site name opens the map');g.closeMap();
for(let i=0;i<60*20;i++)g.frameStep(1/60);ok(errors.length===0,'no errors '+errors.slice(0,2));
