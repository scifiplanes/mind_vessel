const load=require('./dom.js');const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
(async()=>{
 const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 const kill=(g)=>{g.player.dead=true;g.player.hp=0;g.showDeath()};
 // off by default: the dialog waits
 let T=load();T.g.closeDlg();const first=T.g.player;kill(T.g);
 ok(!T.$('dlg').hidden&&!!T.$('autorestart')&&!T.$('autorestart').checked,'game over shows an unchecked Auto-restart box');
 await sleep(6000);ok(T.g.player===first,'unchecked: still waiting after 6 s');
 // tick it: countdown, then a new run
 T.$('autorestart').checked=true;T.$('autorestart').dispatchEvent(new T.w.Event('change'));
 ok(/new vessel in 5/.test(T.$('ar-count').textContent),'checking it starts a countdown: '+T.$('ar-count').textContent);
 ok(T.w.localStorage.getItem('mindvessel.autorestart')==='1','setting saved');
 await sleep(5600);ok(T.g.player!==first&&!T.g.player.dead&&T.$('dlg').hidden,'after 5 s a new vessel wakes');
 // persists: next death restarts on its own
 const second=T.g.player;kill(T.g);ok(T.$('autorestart').checked,'next game over remembers the setting');
 await sleep(5600);ok(T.g.player!==second,'and restarts by itself');
 // unchecking mid-countdown cancels
 const third=T.g.player;kill(T.g);await sleep(1500);T.$('autorestart').checked=false;T.$('autorestart').dispatchEvent(new T.w.Event('change'));
 ok(T.$('ar-count').textContent==='','unchecking clears the countdown');await sleep(5000);ok(T.g.player===third,'and cancels the restart');
 // clicking the button during a countdown doesn't double-start
 T.$('autorestart').checked=true;T.$('autorestart').dispatchEvent(new T.w.Event('change'));await sleep(1200);T.$('dlg-ok').click();const fourth=T.g.player;await sleep(5000);ok(T.g.player===fourth&&!fourth.dead,'manual restart during countdown: only one new vessel');
 // a fresh page load reads the saved setting
 ok(T.errors.length===0,'no errors '+T.errors.slice(0,2));process.exit(0)})();
