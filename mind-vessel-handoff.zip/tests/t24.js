const load=require('./dom.js');const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
const {g,d,$,errors}=load({w:1920,h:1080,simple:true});g.closeDlg();const P=g.player;
P.equip.tool=P.equip.tool||null;P.inv.metal=3;g.openCard({kind:'actor',a:P,pinned:true});g.uiTick();
const gear=$('card').querySelectorAll('.gear'),pk=$('card').querySelectorAll('.pk');ok(gear.length===4,`four equipment slots shown (${[...gear].map(x=>x.title).join(' | ')})`);
ok(pk.length===Object.values(P.inv).filter(v=>v>0).length,`every pack item shown (${pk.length})`);
const gl=$('card').querySelector('.lk.gear');if(gl){gl.click();g.uiTick();ok(g.insp.kind==='gear'&&!!$('card').querySelector('[data-back]'),'tapping gear opens its card with a way back');$('card').querySelector('[data-back]').click();g.uiTick()}
const pl=$('card').querySelector('.pk');pl.click();g.uiTick();ok(g.insp.kind==='mat','tapping a pack item opens the material');
ok(errors.length===0,'no errors');
