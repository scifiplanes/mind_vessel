const load=require('./dom.js');const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
const {g,w,errors}=load({w:1920,h:1080});g.closeDlg();let fake=w.performance.now();w.performance.now=()=>fake;const step=n=>{for(let i=0;i<n;i++){fake+=1000/60;g.frameStep(1/60)}};
const P=g.player;P.hp=P.maxHp=9999;P.mind=[];
// glow: put a Glowcap in a dark spot and check light rises around it after the env refresh
const W=g.map();let spot=-1;for(let i=0;i<W.length;i++){if(W[i]===1&&g.explored()[i]){spot=i;break}}
const x=spot%g.MW,y=(spot/g.MW)|0;const L0=w.eval?0:0;
const before=g.envLight?0:0;
const c=g.spawnAt('plant','Glowcap',spot);c.x=x+.5;c.y=y+.5;
const getL=()=>g.lightAt(spot);const l0=getL();g.rebuildEnvNow();const l1=getL();ok(l1>l0+.3,`Glowcap lights its tile: ${l0.toFixed(2)} → ${l1.toFixed(2)}`);
c.hp=0;g.killNow(c,'test');step(90);ok(getL()<l1-.3,`light fades when it dies: ${getL().toFixed(2)}`);
// thorns
const pv=g.spawnAt('plant','Pipevine',spot);P.comp.species='Crab';P.maxHp=40;P.hp=40;P.mind=['graze'];P.energy=10;P.maxEnergy=100;pv.x=P.x+1;pv.y=P.y;const hp0=P.hp;step(60*3);ok(P.hp<hp0,`grazing a Pipevine pricks the vessel: HP ${hp0} → ${P.hp.toFixed(0)}`);
// kind mix travels with migrants
const s=g.RG.sites[g.RG.cur],nb=g.RG.sites[s.nb[0]];const km=g.kindMix(nb);const before2=km.Bonehound;const b=g.spawnAt('forager','Bonehound');g.npcLeaveNow(b,nb.id);ok(g.kindMix(nb).Bonehound>before2,`a Bonehound leaving raises its weight next door: ${before2.toFixed(2)} → ${g.kindMix(nb).Bonehound.toFixed(2)}`);
step(60*30);ok(errors.length===0,'no errors '+errors.slice(0,2));
