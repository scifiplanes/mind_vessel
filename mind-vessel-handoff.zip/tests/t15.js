const load=require('./dom.js');
const {g,w,errors}=load({w:1920,h:1080});g.closeDlg();let fake=w.performance.now();w.performance.now=()=>fake;
const S=g.RG.sites;const q=S.map(s=>s.Q),n=S.map(s=>s.N);
console.log('region: avg N',(n.reduce((a,b)=>a+b)/S.length).toFixed(1),'avg Q',(q.reduce((a,b)=>a+b)/S.length).toFixed(2),'sites with Q<0.5:',q.filter(x=>x<.5).length,'/',S.length);
const P=g.player;P.hp=P.maxHp=9999;P.mind=[];
let tot={start:0,end:0,sites:0,kills:0};const ids=S.slice(0,10).map(s=>s.id);
for(const id of ids){if(id!==g.RG.cur){g.leaveSite();g.enterSite(id,null,[])}P.dead=false;P.mind=[];P.energy=1e9;P.maxEnergy=1e9;g.closeDlg();
 const hu=()=>g.actors.filter(a=>!a.dead&&a.creature&&a.role==='predator').length;const h0=hu();const gr0=g.actors.filter(a=>!a.dead&&a.creature&&a.role==='forager').length;
 const prey=g.actors.filter(a=>a.creature&&a.role==='forager');
 for(let i=0;i<60*180;i++){fake+=1000/60;P.hp=P.maxHp;g.frameStep(1/60)}
 const h1=hu(),gr1=g.actors.filter(a=>!a.dead&&a.creature&&a.role==='forager').length,eaten=prey.filter(a=>a.dead&&/hunter|Bonehound|Cablesnake/.test(String(a.deathBy))).length;
 tot.start+=h0;tot.end+=h1;tot.sites++;tot.kills+=eaten;console.log(`${g.RG.sites[id].type.padEnd(8)} hunters ${h0}→${h1}  grazers ${gr0}→${gr1}  grazers died ${eaten}`)}
console.log('TOTAL hunters',tot.start,'→',tot.end,'across',tot.sites,'sites; grazers died',tot.kills,errors[0]||'');
