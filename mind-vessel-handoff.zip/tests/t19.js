const load=require('./dom.js');const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
const {g,d,$,w,errors}=load({w:1920,h:1080});g.closeDlg();let fake=w.performance.now();w.performance.now=()=>fake;const step=n=>{for(let i=0;i<n;i++){fake+=1000/60;g.frameStep(1/60)}};
const cnt=v=>{let n=0;for(const x of g.explored())if(x===v)n++;return n};
// Survey Lines
const P=g.player;P.hp=P.maxHp;const s0=cnt(1)+cnt(2);g.surveyLines(P,{x:P.x|0,y:P.y|0,name:'a terminal'});
ok(cnt(2)>100,`survey reveals the site as told tiles: ${s0} → ${cnt(1)+cnt(2)} known (${cnt(2)} told)`);
ok(g.exits.every(e=>g.explored()[e.i]),'every duct is now known');
ok(g.player.mind.length>=0&&(()=>{const r=g.TH.survey;return r&&r.v[0][0]==='SURVEY'})(),'Survey Lines exists');
// seen tiles override told
step(60*5);ok(cnt(1)>s0,'tiles the vessel actually sees turn from told to seen');
// Ask the Way at a civilized site
const civ=g.RG.sites.find(s=>s.civ&&s.S>3&&s.id!==g.RG.cur);g.leaveSite();g.enterSite(civ.id,null,[]);
const b=g.actors.find(a=>!a.dead&&a.civ);const k0=g.RG.sites.filter(s=>s.heardOf).length,t0=cnt(2);
if(b){b.mind.unshift('listen');g.askWay(P,b);ok(cnt(2)>t0,`asking ${b.comp.species} reveals ${cnt(2)-t0} tiles around their home`);
  ok(g.RG.sites.filter(s=>s.heardOf).length>k0,`and ${g.RG.sites.filter(s=>s.heardOf).length-k0} sites on the map`);
  ok(b.asked===P.id,'each person is asked once')}
// Read the Dead
const know=cnt(1)+cnt(2),known=g.RG.sites.filter(s=>s.visited||s.heardOf).length;const oldName=P.comp.name;
g.killNow2(P,'test');step(60*3);g.newVessel();g.closeDlg();
const B=g.player;B.base.WIS=40;B.st.WIS=40;B.mind=[];g.leaveSite();g.enterSite(civ.id,null,[]);const rem=g.objsNow.find(o=>o.vessel===oldName);
ok(!!(rem&&rem.know),'remains carry the map their vessel knew ('+(rem?rem.know.explored.size:0)+' sites of tiles, '+(rem?rem.know.sites.length:0)+' sites on the map)');
// remains are at the civ site; go there
const before=cnt(1)+cnt(2),k1=g.RG.sites.filter(s=>s.heardOf||s.visited).length;
B.x=rem.x+.5;B.y=rem.y+.5;g.recallDead(B,rem);
ok(cnt(1)+cnt(2)>before,`reading the dead restores ${cnt(1)+cnt(2)-before} tiles here`);
console.log('     map sites known:',k1,'→',g.RG.sites.filter(s=>s.heardOf||s.visited).length);
ok(rem.readBy.includes(B.comp.name),'each vessel reads a body once');
// the vessel uses the Thoughts on its own
B.mind=['readdead','askway','survey'];if(!g.save.lib.includes('readdead'))g.save.lib.push('readdead','askway','survey');rem.readBy=[];
const acts=new Set();for(let i=0;i<60*60;i++){fake+=1000/60;g.frameStep(1/60);const it=g.player.intent;if(it)acts.add(it.v)}
ok(acts.has('ASK')||acts.has('RECALL')||acts.has('SURVEY'),'with the Thoughts in its Mind the vessel uses them: '+[...acts].join(', '));
ok(errors.length===0,'no errors '+errors.slice(0,2));
