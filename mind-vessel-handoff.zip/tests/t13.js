const load=require('./dom.js');const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
const {g,d,$,w,errors}=load({w:1920,h:1080});g.closeDlg();let fake=w.performance.now();w.performance.now=()=>fake;
const step=n=>{for(let i=0;i<n;i++){fake+=1000/60;g.frameStep(1/60);if(g.player.dead){g.player.dead=false;g.player.hp=g.player.maxHp}}};
const P=g.player;P.hp=P.maxHp=9999;P.mind=[];
const census=()=>{const c={};for(const a of g.actors)if(!a.dead&&a!==P){const k=a.creature?(a.flora?'plant':a.role==='predator'?'hunter':'grazer'):'person';c[k]=(c[k]||0)+1}return c};
// visit a few sites of different types and watch the food web for two minutes each
const types=new Set();const ids=[];for(const s of g.RG.sites){if(!types.has(s.type)){types.add(s.type);ids.push(s.id)}if(ids.length>=4)break}
let grazes=0,kills=0;const origLog=w.console.log;
for(const id of ids){if(id!==g.RG.cur){g.leaveSite();g.enterSite(id,null,[])}P.energy=1e9;P.maxEnergy=1e9;
  const s=g.RG.sites[id],c0=census();const kinds=[...new Set(g.actors.filter(a=>a.creature&&!a.dead).map(a=>a.comp.species))];
  let gz=0;const before=new Map(g.actors.filter(a=>a.flora).map(a=>[a.id,a.hp]));
  for(let k=0;k<240;k++){step(60);for(const a of g.actors)if(a.flora&&a.grazedT>g.gameTime-1)gz++}
  const c1=census();console.log(`${s.type} ${s.name}: start ${JSON.stringify(c0)} → after 4 min ${JSON.stringify(c1)} | kinds ${kinds.join(', ')} | graze-seconds ${gz}`)}
ok(errors.length===0,'ecosystem runs without errors '+errors.slice(0,2));
// creatures carry no culture and never transfer Thoughts
const cr=g.actors.find(a=>a.creature&&!a.dead);ok(cr&&cr.comp.culture===null&&cr.comp.cls===null&&!cr.civ,'creatures have no culture, class or civilization');
// study: put a fauna creature near the vessel with an unknown instinct
P.mind=['study'];if(!g.save.lib.includes('study'))g.save.lib.push('study');
const fa=g.actors.find(a=>a.creature&&!a.flora&&!a.dead&&a.mind.some(t=>!g.TH[t].hidden&&!g.save.lib.includes(t)));
if(fa){fa.x=P.x+3;fa.y=P.y;fa.mind=fa.mind.filter(t=>t!=='skitter');const lib0=g.save.lib.length;let tries=0;
  while(tries<6&&g.save.lib.length===lib0){fa.studied=false;fa.x=P.x+3;fa.y=P.y;fa.energy=fa.maxEnergy;step(60*6);tries++}
  ok(g.save.lib.length>lib0,`studying a ${fa.comp.species} taught: ${g.save.lib.slice(lib0).map(t=>g.TH[t].n+' ('+g.save.src[t]+')').join(', ')||'nothing'} after ${tries} tries`)}
// graze as the vessel (organic diet needed)
const pl=g.actors.find(a=>a.flora&&!a.dead);if(pl){P.comp.species='Crab';g.player.mind=['graze'];P.energy=10;P.maxEnergy=100;pl.x=P.x+1;pl.y=P.y;const e0=P.energy;step(60*4);ok(P.energy>e0||pl.dead||pl.hp<pl.maxHp,`vessel grazes ${pl.comp.species}: energy ${e0.toFixed(0)}→${P.energy.toFixed(0)}, plant hp ${pl.hp.toFixed(1)}/${pl.maxHp}`)}
// card shows creature info
g.openCard({kind:'actor',a:g.actors.find(a=>a.creature&&!a.dead),pinned:true});const mb=$('card').querySelector('[data-more]');if(mb)mb.click();ok(/creature/.test($('card').textContent),'card: '+$('card').textContent.replace(/\s+/g,' ').slice(0,160));
ok(errors.length===0,'no errors '+errors.slice(0,2));
