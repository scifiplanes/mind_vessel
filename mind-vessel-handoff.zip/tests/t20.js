const load=require('./dom.js');const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
const {g,d,$,w,errors}=load({w:1920,h:1080});g.closeDlg();let fake=w.performance.now();w.performance.now=()=>fake;const step=n=>{for(let i=0;i<n;i++){fake+=1000/60;g.frameStep(1/60)}};
// open the debug panel from the menu and the F9 key
$('b-menu').click();const db=$('menu').querySelector('[data-k="debug"]');ok(!!db,'menu has Debug settings…');db.click();ok(!$('debug').hidden&&$('menu').hidden,'debug panel opens, menu closes');
const fire=(el,v)=>{if(el.type==='checkbox')el.checked=v;else el.value=v;el.dispatchEvent(new w.Event('input',{bubbles:true}))};
fire($('debug').querySelector('[data-db="levels"]'),3);fire($('debug').querySelector('[data-db="matrix"]'),8);fire($('debug').querySelector('[data-db="strength"]'),.5);fire($('debug').querySelector('[data-db="mono"]'),true);
const saved=JSON.parse(w.localStorage.getItem('mindvessel.debug'));ok(saved.levels===3&&saved.matrix===8&&saved.strength===.5&&saved.mono===true,'dither settings apply and persist: '+JSON.stringify(saved));
step(30);ok(errors.length===0,'rendering with 8×8 mono dither has no errors');
fire($('debug').querySelector('[data-db="dither"]'),false);ok(JSON.parse(w.localStorage.getItem('mindvessel.debug')).dither===false,'dither off persists');
// region events in the log
fire($('debug').querySelector('[data-db="regionLog"]'),false);const n0=d.querySelectorAll('#log .ln.region').length;g.rlog('The Debug Test Order is founded at X.',g.RG.sites[g.RG.cur].nb[0]);
ok(d.querySelectorAll('#log .ln.region').length===n0,'with the switch off, region events stay out of the log');
fire($('debug').querySelector('[data-db="regionLog"]'),true);g.rlog('The Second Debug Order is founded at X.',g.RG.sites[g.RG.cur].nb[0]);ok([...d.querySelectorAll('#log .ln.region')].some(l=>/Second Debug/.test(l.textContent)),'with it on, they are logged');
ok((g.RG.news||[]).some(n=>/Debug Test Order/.test(n.text)),'the switch only affects the log: the event still became news in the world');
d.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));ok($('debug').hidden,'Esc closes the panel');
d.dispatchEvent(new w.KeyboardEvent('keydown',{key:'F9',bubbles:true}));ok(!$('debug').hidden,'F9 opens it');d.body.click();ok($('debug').hidden,'clicking outside closes it');
// card closes on click
g.openCard({kind:'actor',a:g.player,pinned:true});g.uiTick();$('card').querySelector('.row').click();ok($('card').hidden,'clicking the card body closes it');
g.openCard({kind:'actor',a:g.player,pinned:true});g.uiTick();const more=$('card').querySelector('[data-more]');if(more){more.click();ok(!$('card').hidden,'"more" still expands instead of closing')}
const lk=$('card').querySelector('[data-m]');if(lk){lk.click();ok(!$('card').hidden&&g.insp.kind==='mat','material links still drill down')}
ok(errors.length===0,'no errors '+errors.slice(0,2));
