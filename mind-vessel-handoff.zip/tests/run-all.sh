#!/bin/sh
# runs every suite and prints pass/fail counts; needs `npm install` first
cd "$(dirname "$0")"
for t in t1 t4 t5 t6 t8 t11 t12 t13 t17 t18 t19 t20 t21 t22 t23 t24 t25; do
  out=$(timeout 200 node $t.js 2>&1); echo "$t: $(echo "$out" | grep -c '^PASS') pass, $(echo "$out" | grep -c '^FAIL') fail"
  echo "$out" | grep '^FAIL' | sed 's/^/    /'
done
