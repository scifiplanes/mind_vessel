const load=require('./dom.js');
const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
for(const [name,o] of [['wide 1920×1080',{w:1920,h:1080}],['narrower desktop 1100×860',{w:1100,h:860}],['phone',{narrow:true,w:390,h:844}]]){
  const {g,d,$,w,errors}=load(o);g.closeDlg();for(let i=0;i<60*15;i++)g.frameStep(1/60);
  console.log('--',name,'→ layout',g.layout,'| app class',$('app').className);
  const rows=[...d.querySelectorAll('#mindrows .th')];
  ok(rows.every((r,i)=>r.querySelector('.no').textContent==String(i+1)&&r.dataset.t===g.player.mind[i]),'single list in Mind order, numbered 1…'+rows.length);
  ok(!/nothing to do/.test(d.querySelector('#mindrows').textContent),'repeated "nothing to do" collapsed to "idle"');
  const libHome=$('lib-pane').parentNode.id;console.log('     Library lives in:',libHome);
  if(g.layout==='bottom'){ok(libHome==='pane-mind','bottom: Library is the third pane');ok($('mdetail').textContent.length>5,'bottom: detail pane: '+$('mdetail').textContent.slice(0,90));
    const r2=rows[1];if(r2){r2.click();g.uiTick();ok($('mdetail').textContent.startsWith('#2'),'bottom: selecting a row shows it in the detail pane');ok(!d.querySelector('#mindrows .sub'),'bottom: no inline verb rows')}
    g.uiTick();ok(d.querySelectorAll('#lib .card').length>0,'bottom: Library cards visible with the Mind');
    g.cmd('l');ok(g.dockTab==='mind','bottom: L focuses the Library pane')}
  if(g.layout==='side'){ok(libHome==='drawer','side: Library in the drawer');rows[0].click();g.uiTick();ok(!!d.querySelector('#mindrows .sub'),'side: selected Thought expands verbs in place');g.cmd('l');ok(g.drawerOpen,'side: L opens drawer')}
  g.showDock('ves');g.uiTick();
  ok(d.querySelectorAll('#sh-stat .vsec').length===3&&/HP/.test($('sh-dyn').textContent),'Vessel: one view, sections '+[...d.querySelectorAll('.vsec h4')].map(h=>h.textContent.split(' ')[0]).join(' · '));
  const lk=d.querySelector('#sh-stat [data-m]');if(lk){lk.click();ok(g.insp&&g.insp.kind==='mat','Vessel material opens a card')}
  g.showDock('mind');for(let i=0;i<60*10;i++)g.frameStep(1/60);ok(errors.length===0,'no errors '+errors.slice(0,2));
  // live resize between layouts
  if(name.startsWith('wide')){w.innerWidth=1100;w.innerHeight=860;g.applyLayout();g.uiTick();ok(g.layout==='bottom'&&$('lib-pane').parentNode.id==='pane-mind'&&!g.drawerOpen,'resize wide → bottom moves Library into the dock and closes the drawer');
    w.innerWidth=1920;w.innerHeight=1080;g.applyLayout();g.uiTick();ok(g.layout==='side'&&$('lib-pane').parentNode.id==='drawer','resize back → side');
    for(let i=0;i<60*5;i++)g.frameStep(1/60);ok(errors.length===0,'no errors after resizing')}
}
