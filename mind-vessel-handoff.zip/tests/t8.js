const load=require('./dom.js');const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
const {g,d,$,w,errors}=load({w:1920,h:1080});g.closeDlg();
let fake=w.performance.now();w.performance.now=()=>fake;const step=n=>{for(let i=0;i<n;i++){fake+=1000/60;g.frameStep(1/60)}};
step(60*90);
ok(d.querySelectorAll('.toast').length===0,'no omniscient toasts');
const reg=[...d.querySelectorAll('#log .ln.region')];ok(reg.length>0,`Region debug log keeps events (${reg.length}), e.g. "${reg.length?reg[reg.length-1].textContent.slice(0,80):''}"`);
console.log('     news recorded:',(g.RG.news||[]).length,'| heard so far:',g.heardN.size);
// civ site with people: go somewhere civilized, put a talker next to the vessel
const civSite=g.RG.sites.find(s=>s.civ&&s.S>3&&s.id!==g.RG.cur);g.leaveSite();g.enterSite(civSite.id,null,[]);step(60);
const P=g.player,talker=g.actors.find(a=>!a.dead&&a.civ);
ok(!!talker,'a civilization member is present');
if(talker){talker.x=P.x+1.5;talker.y=P.y;talker.gossipT=0;talker.mind.unshift('listen');
  g.newsAdd(g.RG.cur,'TEST: The Grey Choir is founded here.',true);
  // player without social Thoughts: fragments
  P.mind=P.mind.filter(t=>!g.TH[t].v.some(v=>['LISTEN','TRADE','PREACH'].includes(v[0])));
  let heard=null;for(let i=0;i<60*40&&!heard;i++){fake+=1000/60;g.frameStep(1/60);talker.x=P.x+1.5;talker.y=P.y;const b=d.querySelector('.bark.news');if(b)heard=b.textContent}
  ok(!!heard,'NPC barks news in the world: '+heard);ok(heard&&heard.startsWith('«…'),'without a social Thought the vessel catches only fragments');
  const nb=d.querySelector('.bark.news');if(nb&&nb.dataset.site!=null){nb.click();ok(g.mapOpen,'clicking news opens the map at its site');g.closeMap()}
  // now with Listen: full text
  P.mind.unshift('listen');g.newsAdd(g.RG.cur,'TEST: War between The Grey Choir and The Ash Kin at here and there.',true);talker.gossipT=0;
  let full=null;for(let i=0;i<60*40&&!full;i++){fake+=1000/60;g.frameStep(1/60);talker.x=P.x+1.5;talker.y=P.y;for(const b of d.querySelectorAll('.bark.news'))if(/War between The Grey Choir/.test(b.textContent))full=b.textContent}
  ok(!!full,'with Listen in the Mind the vessel follows the whole thing: '+(full||'').slice(0,70))}
// terminals and live lines
g.newsAdd(5,'TEST: Famine at Far Site.',true);
const term={x:P.x|0,y:P.y|0,name:'a terminal',o:{}};g.scanFeed(P,term);ok([...d.querySelectorAll('.bark.news')].some(b=>/▤ TEST: Famine/.test(b.textContent)),'Read the Feeds on a terminal shows region news as ▤');
ok(g.RG.sites[5].heardOf,'hearing about a site makes it known on the map');

// the vessel actually uses SCAN when the Thought is in its Mind
const hasFeeds=g.save.lib.includes('feeds');console.log('     this vessel has Read the Feeds in its Library:',hasFeeds);
// log autoscroll
const L=$('pane-log');g.showDock('log');Object.defineProperty(L,'clientHeight',{value:200,configurable:true});Object.defineProperty(L,'scrollHeight',{get:()=>5000,configurable:true});
L.scrollTop=4800;L.dispatchEvent(new w.Event('scroll'));ok(g.logPinned,'at the bottom: pinned');
g.newsAdd(null,'x',false);P.hp=P.hp;w.eval;g.uiTick();
L.scrollTop=1000;L.dispatchEvent(new w.Event('scroll'));ok(!g.logPinned,'scrolled up: unpinned');
const before=L.scrollTop;g.hearNews({id:99999,site:null,text:'TEST log line'},P,'full');ok(L.scrollTop===before,'new lines do not yank the view while scrolled up');
L.scrollTop=4800;L.dispatchEvent(new w.Event('scroll'));g.hearNews({id:99998,site:null,text:'TEST log line 2'},P,'full');ok(L.scrollTop===5000,'back at the bottom: follows new lines');
step(60*30);ok(errors.length===0,'no errors '+errors.slice(0,3));
