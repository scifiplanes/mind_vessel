// pulls the game script out of the HTML into game.js, for play.js (the older stub-DOM gameplay harness)
const fs=require('fs'),p=require('path');const s=fs.readFileSync(p.join(__dirname,'..','mind-vessel.html'),'utf8');
fs.writeFileSync(p.join(__dirname,'game.js'),s.match(/<script>([\s\S]*)<\/script>/)[1]);console.log('wrote game.js');
