const load=require('./dom.js');const ok=(c,m)=>console.log((c?'PASS ':'FAIL ')+m);
for(const o of [{w:1920,h:1080,simple:true},{w:1100,h:860,simple:true},{narrow:true,w:390,h:844,simple:true}]){
 const {g,d,$,errors}=load(o);g.closeDlg();g.uiTick();const tag=o.narrow?'phone':o.w>1500?'wide':'narrow desktop';
 const plus=d.querySelector('#mindrows [data-lib]');
 if(g.layout==='bottom'){ok(!plus&&d.querySelectorAll('#lib .card').length>0,`${tag}: Library is already open beside the Mind`)}
 else{ok(!!plus,`${tag}: ＋ under the Mind`);plus.click();g.uiTick();ok(g.layout==='side'?g.drawerOpen:g.dockTab==='lib',`${tag}: ＋ opens the Library`)}
 const before=g.player.mind.length;const add=[...d.querySelectorAll('#lib [data-add]')].find(b=>g.TH[b.dataset.add].c<=g.player.mindCap-g.mindCost(g.player));
 if(add){const tid=add.dataset.add;add.click();g.uiTick();if(g.layout==='phone'){const sl=d.querySelector('#mindrows .slot[data-slot]');sl.click()}ok(g.player.mind.includes(tid),`${tag}: + on a card equips ${g.TH[tid].n}`)}
 ok(errors.length===0,`${tag}: no errors`)}
